(function() {
	window.antiAdBlock = {
		onDetected: function() {
			;
		},
		onNotDetected: function(a) {
			a();
		}
	};
})();
